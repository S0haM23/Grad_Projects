#! /usr/bin/env python
import numpy as np
import math
import rospy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from tf import transformations

twist = Twist()
class Astar:
    def __init__(self, parent=None, pose=None):
        self.parent = parent
        self.pose = pose
        self.g = 0
        self.f = 0       
    def __eq__(self, other):
        return self.pose == other.pose

def path(current_node,grid):
    global the_way
    the_way = []
    current = current_node
    while current is not None:
        the_way.append(current.pose)
        current = current.parent
    the_way.reverse()
    for i,start in enumerate(the_way):
        grid[the_way[i][0]][the_way[i][1]] = start
    return grid

def search(grid, start, end):
    global the_way
    start_node = Astar(None,start)
    end_node = Astar(None,end)
    start_node.g = 0
    start_node.f = 0
    end_node.g = 9999
    end_node.f = 9999
    open_list = []  
    closed_list = [] 

    open_list.append(start_node)

    top = [-1,0]#     top_right =[-1,1]
    right =[0,1]#     bottom_right =[1,1]
    bottom =[1,0]#     bottom_left =[1,-1]
    left =[0,-1]#     top_left =[-1,-1]
    directions = [top,right,bottom,left]#[top,top_right,right,bottom_right,bottom,bottom_left,left,top_left] # uncomment to move diagonally
    row, col = np.shape(grid)  

    while len(open_list) != 0:
        current_node = open_list[0]
        current_pos = 0
        for i in range(len(open_list)):
            if open_list[i].f < current_node.f:
                current_node = open_list[i]
                current_pos = i            

        open_list.pop(current_pos)
        closed_list.append(current_node)
        # test if goal is reached or not, if yes then return the path
        if current_node == end_node:
            return path(current_node,grid),the_way
        # Generate children from all adjacent squares
        children = []
        for dirct in directions: 
            node_position = (current_node.pose[0] + dirct[0], current_node.pose[1] + dirct[1]) 
            
            if (node_position[0] >= (row) or     
                node_position[0] and node_position[1] < 0 or          ## if node goes out of bounds 
                node_position[1] >= (col)) or grid[node_position[0]][node_position[1]] != 0 :
#                 print("Out of bounds...Turn Back!!")
                continue
            if grid[node_position[0]][node_position[1]] != 0: # if node detects an obstacle
#                 print("Obstacle detected!!")
                continue
            child_node = Astar(current_node, node_position)
            children.append(child_node)
            
        for child in children:
            counter = 0
            for v_c in closed_list: # iterate through closed list
                if v_c == child:    # if child already exists in closed list... ignore it
                    counter+=1
            if counter>0:
                continue
            # Create the g,h and f values
            child.g = current_node.g + 1 # cost of moving single block is assumed 1
            h_dist = ((end_node.pose[0] - child.pose[0])**2  + (end_node.pose[1] - child.pose[1])**2)
            child.f = child.g + h_dist
            for open_node in open_list:
                if child == open_node and child.g > open_node.g:
                    continue
            open_list.append(child)

def position_callback(odom):
    global counter,theta,yaw,the_way,cur_y,cur_x,i

    xval = odom.pose.pose.position.x                                        
    yval = odom.pose.pose.position.y  

    quaternion = (
        odom.pose.pose.orientation.x,
        odom.pose.pose.orientation.y,                                         ## convert all angles to euler
        odom.pose.pose.orientation.z,
        odom.pose.pose.orientation.w)

    euler = transformations.euler_from_quaternion(quaternion)               
    yaw = math.degrees(euler[2])                                                ## get current orientation of robot WRT world
    cur_y = int(round(10-yval))
    cur_x = int(round(xval+9))

    if (cur_y,cur_x) != end:
        if (cur_y,cur_x) == start:
            i = 0
        if (cur_y,cur_x) == (the_way[i+1][0],the_way[i+1][1]):
            print('switched')
            i+=1
    goal_seek(cur_y,cur_x,i)

def goal_seek(cur_y,cur_x,i):
    if (cur_y,cur_x) != end:
        print("currently on",cur_y,cur_x)
        y = (the_way[i][0]-the_way[i+1][0])
        x = (the_way[i][1]-the_way[i+1][1])
        started_from = (the_way[i][0],the_way[i][1])
        goal = (the_way[i+1][0],the_way[i+1][1])
        print("started from",started_from)
        print("next goal",goal)   
        print("on node :",i)
        if x > 0:
            theta = 2*math.degrees(math.atan(y))
            theta+=180   
        else:
            theta = 2*math.degrees(math.atan(y))
        # theta = 2*math.degrees(math.atan(y)) 
        print(round(theta),round(yaw))              
        if round(yaw) == round(theta):
            twist.angular.z = 0
            twist.linear.x = 0.5
            pub.publish(twist)
        else:
            if round(theta) > round(yaw):
                if round(yaw) < round(theta)-3:
                    twist.angular.z = 0.5
                    twist.linear.x = 0
                    pub.publish(twist)
                else:
                    twist.angular.z = 0.1
                    twist.linear.x = 0
                    pub.publish(twist)
            elif round(theta) < round(yaw):
                if round(yaw) > round(theta)+3:
                    twist.angular.z = -0.5
                    twist.linear.x = 0
                    pub.publish(twist)
                else:
                    twist.angular.z = -0.1
                    twist.linear.x = 0
                    pub.publish(twist)
    else:   
        twist.linear.x = 0
        twist.angular.z = 0
        pub.publish(twist)
        print("goal reached")                

if __name__ == '__main__':
    global pub,end,start
    if rospy.has_param("/astar/goalx") and rospy.has_param("/astar/goaly"):
        end_x = rospy.get_param("/astar/goalx")
        end_y = rospy.get_param("/astar/goaly")
    end = (10-end_y,end_x+9)
    # end = (10,7) # end
    end = (round(end[0]),round(end[1]))
    start = (12,1) # start


    rospy.init_node("astar")
    pub = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
    # sleep(0.6)
    rospy.Subscriber("/base_pose_ground_truth", Odometry,position_callback)

    grid = [[0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0],
            [0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0],
            [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
            [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
            [0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
            [0,0,1,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0],
            [0,0,1,1,0,0,1,1,1,1,1,1,1,1,0,0,0,0],
            [0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0],
            [0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,1,1],
            [0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1,1,1],
            [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1],
            [0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1,0],
            [0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,1,1,0,0,0,1,1,1,1,0],
            [0,0,0,0,0,0,0,0,1,1,1,0,0,1,1,1,1,0],
            [0,0,0,0,0,0,0,1,1,1,0,0,0,1,1,1,1,0],
            [0,0,0,0,0,0,0,0,1,1,0,0,0,1,1,1,1,1]]

    path,the_way = search(grid, start, end)
    print("coordinates to the goal are",the_way)

    rospy.spin()
